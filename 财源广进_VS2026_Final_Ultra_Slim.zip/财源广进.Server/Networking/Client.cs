﻿using 财源广进.Common.Messages;
using 财源广进.Common.Networking;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Security;
using System.Threading;
using System.IO;

namespace 财源广进.Server.Networking
{
    public class Client : IEquatable<Client>, ISender
    {
        public event ClientStateEventHandler ClientState;
        public delegate void ClientStateEventHandler(Client s, bool connected);

        private void OnClientState(bool connected)
        {
            if (Connected == connected) return;
            Connected = connected;
            var handler = ClientState;
            handler?.Invoke(this, connected);
        }

        public event ClientReadEventHandler ClientRead;
        public delegate void ClientReadEventHandler(Client s, IMessage message, int messageLength);

        private void OnClientRead(IMessage message, int messageLength)
        {
            var handler = ClientRead;
            handler?.Invoke(this, message, messageLength);
        }

        public event ClientWriteEventHandler ClientWrite;
        public delegate void ClientWriteEventHandler(Client s, IMessage message, int messageLength);

        private void OnClientWrite(IMessage message, int messageLength)
        {
            var handler = ClientWrite;
            handler?.Invoke(this, message, messageLength);
        }

        public bool Equals(Client other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return this.EndPoint.Port.Equals(other.EndPoint.Port);
        }

        public override bool Equals(object obj) => this.Equals(obj as Client);
        public override int GetHashCode() => this.EndPoint.GetHashCode();

        public enum ReceiveType
        {
            Header,
            Payload
        }

        private readonly SslStream _stream;
        private readonly BufferPool _bufferPool;
        private readonly Queue<IMessage> _sendBuffers = new Queue<IMessage>();
        private bool _sendingMessages;
        private readonly object _sendingMessagesLock = new object();
        private readonly Queue<byte[]> _readBuffers = new Queue<byte[]>();
        private bool _readingMessages;
        private readonly object _readingMessagesLock = new object();

        private int _readOffset;
        private int _writeOffset;
        private int _readableDataLen;
        private int _payloadLen;
        private ReceiveType _receiveState = ReceiveType.Header;

        public DateTime ConnectedTime { get; }
        public bool Connected { get; private set; }
        public bool Identified { get; set; }
        public UserState Value { get; set; }
        public IPEndPoint EndPoint { get; }

        private readonly byte[] _readBuffer;
        private byte[] _payloadBuffer;
        private const int HeaderSize = 4;
        private const int MaxMessageSize = (1024 * 1024) * 10;

        public Client(BufferPool bufferPool, SslStream stream, IPEndPoint endPoint)
        {
            Identified = false;
            Value = new UserState();
            EndPoint = endPoint;
            ConnectedTime = DateTime.UtcNow;
            _stream = stream;
            _bufferPool = bufferPool;
            _readBuffer = _bufferPool.GetBuffer();
            
            try 
            {
                _stream.BeginRead(_readBuffer, 0, _readBuffer.Length, AsyncReceive, null);
                OnClientState(true);
            }
            catch (Exception)
            {
                Disconnect();
            }
        }

        private void AsyncReceive(IAsyncResult result)
        {
            try
            {
                int bytesTransferred = _stream.EndRead(result);
                if (bytesTransferred <= 0)
                {
                    Disconnect();
                    return;
                }

                byte[] received = new byte[bytesTransferred];
                Array.Copy(_readBuffer, received, bytesTransferred);

                lock (_readBuffers)
                {
                    _readBuffers.Enqueue(received);
                }

                lock (_readingMessagesLock)
                {
                    if (!_readingMessages)
                    {
                        _readingMessages = true;
                        ThreadPool.QueueUserWorkItem(ProcessReadBuffers);
                    }
                }

                _stream.BeginRead(_readBuffer, 0, _readBuffer.Length, AsyncReceive, null);
            }
            catch
            {
                Disconnect();
            }
        }

        private void ProcessReadBuffers(object state)
        {
            while (true)
            {
                byte[] readBuffer;
                lock (_readBuffers)
                {
                    if (_readBuffers.Count == 0)
                    {
                        lock (_readingMessagesLock)
                        {
                            _readingMessages = false;
                        }
                        return;
                    }
                    readBuffer = _readBuffers.Dequeue();
                }

                _readableDataLen = readBuffer.Length;
                _readOffset = 0;

                while (_readableDataLen > 0)
                {
                    if (_receiveState == ReceiveType.Header)
                    {
                        if (_payloadBuffer == null) _payloadBuffer = new byte[HeaderSize];
                        int toCopy = Math.Min(_readableDataLen, HeaderSize - _writeOffset);
                        Array.Copy(readBuffer, _readOffset, _payloadBuffer, _writeOffset, toCopy);
                        _writeOffset += toCopy;
                        _readOffset += toCopy;
                        _readableDataLen -= toCopy;

                        if (_writeOffset == HeaderSize)
                        {
                            _payloadLen = BitConverter.ToInt32(_payloadBuffer, 0);
                            if (_payloadLen <= 0 || _payloadLen > MaxMessageSize)
                            {
                                Disconnect();
                                return;
                            }
                            _payloadBuffer = new byte[_payloadLen];
                            _writeOffset = 0;
                            _receiveState = ReceiveType.Payload;
                        }
                    }
                    else
                    {
                        int toCopy = Math.Min(_readableDataLen, _payloadLen - _writeOffset);
                        Array.Copy(readBuffer, _readOffset, _payloadBuffer, _writeOffset, toCopy);
                        _writeOffset += toCopy;
                        _readOffset += toCopy;
                        _readableDataLen -= toCopy;

                        if (_writeOffset == _payloadLen)
                        {
                            using (MemoryStream ms = new MemoryStream(_payloadBuffer))
                            {
                                try 
                                {
                                    IMessage message = 财源广进.Common.Messages.MsgSerializer.Deserialize(ms);
                                    OnClientRead(message, _payloadLen + HeaderSize);
                                }
                                catch {}
                            }
                            _payloadBuffer = null;
                            _writeOffset = 0;
                            _receiveState = ReceiveType.Header;
                        }
                    }
                }
            }
        }

        public void Send<T>(T message) where T : IMessage
        {
            if (!Connected) return;
            lock (_sendBuffers)
            {
                _sendBuffers.Enqueue(message);
                lock (_sendingMessagesLock)
                {
                    if (!_sendingMessages)
                    {
                        _sendingMessages = true;
                        ThreadPool.QueueUserWorkItem(ProcessSendBuffers);
                    }
                }
            }
        }

        public void SendBlocking<T>(T message) where T : IMessage
        {
            if (!Connected) return;
            lock (_sendingMessagesLock)
            {
                try
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        财源广进.Common.Messages.MsgSerializer.Serialize(ms, message);
                        byte[] payload = ms.ToArray();
                        byte[] header = BitConverter.GetBytes(payload.Length);
                        _stream.Write(header, 0, header.Length);
                        _stream.Write(payload, 0, payload.Length);
                        _stream.Flush();
                        OnClientWrite(message, payload.Length + HeaderSize);
                    }
                }
                catch
                {
                    Disconnect();
                }
            }
        }

        private void ProcessSendBuffers(object state)
        {
            while (true)
            {
                IMessage message;
                lock (_sendBuffers)
                {
                    if (_sendBuffers.Count == 0)
                    {
                        lock (_sendingMessagesLock)
                        {
                            _sendingMessages = false;
                        }
                        return;
                    }
                    message = _sendBuffers.Dequeue();
                }

                try
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        财源广进.Common.Messages.MsgSerializer.Serialize(ms, message);
                        byte[] payload = ms.ToArray();
                        byte[] header = BitConverter.GetBytes(payload.Length);
                        _stream.Write(header, 0, header.Length);
                        _stream.Write(payload, 0, payload.Length);
                        _stream.Flush();
                        OnClientWrite(message, payload.Length + HeaderSize);
                    }
                }
                catch
                {
                    Disconnect();
                    return;
                }
            }
        }

        public void Disconnect()
        {
            if (!Connected) return;
            try 
            {
                _stream.Close();
            }
            catch {}
            OnClientState(false);
        }
    }
}
