﻿namespace 财源广进.Server.Enums
{
    public enum TransferType
    {
        Upload,
        Download
    }
}
