﻿using 财源广进.Server.Controls;

namespace 财源广进.Server.Forms
{
    partial class FrmBuilder
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnBuild = new System.Windows.Forms.Button();
            this.builderTabs = new 财源广进.Server.Controls.DotNetBarTabControl();
            this.generalPage = new System.Windows.Forms.TabPage();
            this.comboBoxOutputFormat = new System.Windows.Forms.ComboBox();
            this.lblOutputFormat = new System.Windows.Forms.Label();
            this.txtTag = new System.Windows.Forms.TextBox();
            this.lblTag = new System.Windows.Forms.Label();
            this.txtMutex = new System.Windows.Forms.TextBox();
            this.btnMutex = new System.Windows.Forms.Button();
            this.lblMutex = new System.Windows.Forms.Label();
            this.connectionPage = new System.Windows.Forms.TabPage();
            this.numericUpDownPort = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownDelay = new System.Windows.Forms.NumericUpDown();
            this.lstHosts = new System.Windows.Forms.ListBox();
            this.btnAddHost = new System.Windows.Forms.Button();
            this.lblHost = new System.Windows.Forms.Label();
            this.txtHost = new System.Windows.Forms.TextBox();
            this.lblDelay = new System.Windows.Forms.Label();
            this.lblPort = new System.Windows.Forms.Label();
            this.lblMS = new System.Windows.Forms.Label();
            this.monitoringTab = new System.Windows.Forms.TabPage();
            this.chkKeylogger = new System.Windows.Forms.CheckBox();
            this.txtLogDirectoryName = new System.Windows.Forms.TextBox();
            this.chkHideLogDirectory = new System.Windows.Forms.CheckBox();
            this.lblLogDirectory = new System.Windows.Forms.Label();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.removeHostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();

            this.builderTabs.SuspendLayout();
            this.generalPage.SuspendLayout();
            this.connectionPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDelay)).BeginInit();
            this.monitoringTab.SuspendLayout();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();

            // btnBuild
            this.btnBuild.Location = new System.Drawing.Point(402, 390);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.Size = new System.Drawing.Size(121, 23);
            this.btnBuild.Text = "Build Client";
            this.btnBuild.Click += new System.EventHandler(this.btnBuild_Click);

            // builderTabs
            this.builderTabs.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.builderTabs.Controls.Add(this.generalPage);
            this.builderTabs.Controls.Add(this.connectionPage);
            this.builderTabs.Controls.Add(this.monitoringTab);
            this.builderTabs.Dock = System.Windows.Forms.DockStyle.Top;
            this.builderTabs.ItemSize = new System.Drawing.Size(44, 136);
            this.builderTabs.Location = new System.Drawing.Point(0, 0);
            this.builderTabs.Multiline = true;
            this.builderTabs.Name = "builderTabs";
            this.builderTabs.SelectedIndex = 0;
            this.builderTabs.Size = new System.Drawing.Size(535, 384);
            this.builderTabs.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;

            // generalPage
            this.generalPage.BackColor = System.Drawing.SystemColors.Control;
            this.generalPage.Controls.Add(this.lblOutputFormat);
            this.generalPage.Controls.Add(this.comboBoxOutputFormat);
            this.generalPage.Controls.Add(this.lblTag);
            this.generalPage.Controls.Add(this.txtTag);
            this.generalPage.Controls.Add(this.lblMutex);
            this.generalPage.Controls.Add(this.txtMutex);
            this.generalPage.Controls.Add(this.btnMutex);
            this.generalPage.Location = new System.Drawing.Point(140, 4);
            this.generalPage.Name = "generalPage";
            this.generalPage.Size = new System.Drawing.Size(391, 376);
            this.generalPage.Text = "General Settings";

            this.lblOutputFormat.Location = new System.Drawing.Point(20, 25);
            this.lblOutputFormat.Size = new System.Drawing.Size(100, 13);
            this.lblOutputFormat.Text = "Output Format:";
            this.comboBoxOutputFormat.Location = new System.Drawing.Point(125, 22);
            this.comboBoxOutputFormat.Size = new System.Drawing.Size(200, 21);
            this.comboBoxOutputFormat.Items.AddRange(new object[] { "Executable (.exe)", "Binary (.bin)", "Raw Shellcode (.raw)" });
            this.comboBoxOutputFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.lblTag.Location = new System.Drawing.Point(20, 65);
            this.lblTag.Size = new System.Drawing.Size(100, 13);
            this.lblTag.Text = "Client Tag:";
            this.txtTag.Location = new System.Drawing.Point(125, 62);
            this.txtTag.Size = new System.Drawing.Size(200, 20);

            this.lblMutex.Location = new System.Drawing.Point(20, 105);
            this.lblMutex.Size = new System.Drawing.Size(100, 13);
            this.lblMutex.Text = "Mutex:";
            this.txtMutex.Location = new System.Drawing.Point(125, 102);
            this.txtMutex.Size = new System.Drawing.Size(150, 20);
            this.btnMutex.Location = new System.Drawing.Point(280, 100);
            this.btnMutex.Size = new System.Drawing.Size(45, 23);
            this.btnMutex.Text = "Gen";
            this.btnMutex.Click += new System.EventHandler(this.btnMutex_Click);

            // connectionPage
            this.connectionPage.BackColor = System.Drawing.SystemColors.Control;
            this.connectionPage.Controls.Add(this.lblHost);
            this.connectionPage.Controls.Add(this.txtHost);
            this.connectionPage.Controls.Add(this.lblPort);
            this.connectionPage.Controls.Add(this.numericUpDownPort);
            this.connectionPage.Controls.Add(this.btnAddHost);
            this.connectionPage.Controls.Add(this.lstHosts);
            this.connectionPage.Controls.Add(this.lblDelay);
            this.connectionPage.Controls.Add(this.numericUpDownDelay);
            this.connectionPage.Controls.Add(this.lblMS);
            this.connectionPage.Location = new System.Drawing.Point(140, 4);
            this.connectionPage.Name = "connectionPage";
            this.connectionPage.Size = new System.Drawing.Size(391, 376);
            this.connectionPage.Text = "Connection Settings";

            this.lblHost.Location = new System.Drawing.Point(175, 25);
            this.lblHost.Size = new System.Drawing.Size(75, 13);
            this.lblHost.Text = "IP/Hostname:";
            this.txtHost.Location = new System.Drawing.Point(254, 22);
            this.txtHost.Size = new System.Drawing.Size(129, 22);
            this.txtHost.TabIndex = 1;

            this.lblPort.Location = new System.Drawing.Point(175, 53);
            this.lblPort.Size = new System.Drawing.Size(31, 13);
            this.lblPort.Text = "Port:";
            this.numericUpDownPort.Location = new System.Drawing.Point(254, 51);
            this.numericUpDownPort.Size = new System.Drawing.Size(129, 22);
            this.numericUpDownPort.Maximum = new decimal(new int[] { 65535, 0, 0, 0 });
            this.numericUpDownPort.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numericUpDownPort.Value = new decimal(new int[] { 4782, 0, 0, 0 });

            this.btnAddHost.Location = new System.Drawing.Point(254, 78);
            this.btnAddHost.Size = new System.Drawing.Size(129, 22);
            this.btnAddHost.Text = "Add Host";
            this.btnAddHost.Click += new System.EventHandler(this.btnAddHost_Click);

            this.lstHosts.Location = new System.Drawing.Point(20, 21);
            this.lstHosts.Size = new System.Drawing.Size(149, 121);
            this.lstHosts.ContextMenuStrip = this.contextMenuStrip;

            this.lblDelay.Location = new System.Drawing.Point(17, 182);
            this.lblDelay.Size = new System.Drawing.Size(200, 13);
            this.lblDelay.Text = "Time to wait between reconnect tries:";
            this.numericUpDownDelay.Location = new System.Drawing.Point(276, 178);
            this.numericUpDownDelay.Size = new System.Drawing.Size(80, 22);
            this.numericUpDownDelay.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            this.numericUpDownDelay.Value = new decimal(new int[] { 5000, 0, 0, 0 });
            this.lblMS.Location = new System.Drawing.Point(356, 183);
            this.lblMS.Text = "ms";

            // monitoringTab
            this.monitoringTab.BackColor = System.Drawing.SystemColors.Control;
            this.monitoringTab.Controls.Add(this.chkKeylogger);
            this.monitoringTab.Controls.Add(this.txtLogDirectoryName);
            this.monitoringTab.Controls.Add(this.chkHideLogDirectory);
            this.monitoringTab.Controls.Add(this.lblLogDirectory);
            this.monitoringTab.Location = new System.Drawing.Point(140, 4);
            this.monitoringTab.Name = "monitoringTab";
            this.monitoringTab.Size = new System.Drawing.Size(391, 376);
            this.monitoringTab.Text = "Monitoring Settings";

            this.chkKeylogger.Location = new System.Drawing.Point(20, 21);
            this.chkKeylogger.Text = "Enable Keylogger";
            this.lblLogDirectory.Location = new System.Drawing.Point(17, 47);
            this.lblLogDirectory.Text = "Log Directory Name:";
            this.txtLogDirectoryName.Location = new System.Drawing.Point(262, 44);
            this.txtLogDirectoryName.Size = new System.Drawing.Size(118, 22);
            this.chkHideLogDirectory.Location = new System.Drawing.Point(20, 72);
            this.chkHideLogDirectory.Text = "Set directory attributes to hidden";

            // contextMenuStrip
            this.removeHostToolStripMenuItem.Text = "Remove host";
            this.removeHostToolStripMenuItem.Click += new System.EventHandler(this.removeHostToolStripMenuItem_Click);
            this.clearToolStripMenuItem.Text = "Clear all";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.removeHostToolStripMenuItem, this.clearToolStripMenuItem });

            // FrmBuilder
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 425);
            this.Controls.Add(this.btnBuild);
            this.Controls.Add(this.builderTabs);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmBuilder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "财源广进 - Builder";
            this.Load += new System.EventHandler(this.FrmBuilder_Load);

            this.builderTabs.ResumeLayout(false);
            this.generalPage.ResumeLayout(false);
            this.generalPage.PerformLayout();
            this.connectionPage.ResumeLayout(false);
            this.connectionPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDelay)).EndInit();
            this.monitoringTab.ResumeLayout(false);
            this.monitoringTab.PerformLayout();
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button btnBuild;
        private 财源广进.Server.Controls.DotNetBarTabControl builderTabs;
        private System.Windows.Forms.TabPage generalPage;
        private System.Windows.Forms.TabPage connectionPage;
        private System.Windows.Forms.TabPage monitoringTab;
        private System.Windows.Forms.TextBox txtTag;
        private System.Windows.Forms.Label lblTag;
        private System.Windows.Forms.TextBox txtMutex;
        private System.Windows.Forms.Button btnMutex;
        private System.Windows.Forms.Label lblMutex;
        private System.Windows.Forms.ComboBox comboBoxOutputFormat;
        private System.Windows.Forms.Label lblOutputFormat;
        private System.Windows.Forms.NumericUpDown numericUpDownPort;
        private System.Windows.Forms.NumericUpDown numericUpDownDelay;
        private System.Windows.Forms.ListBox lstHosts;
        private System.Windows.Forms.Button btnAddHost;
        private System.Windows.Forms.Label lblHost;
        private System.Windows.Forms.TextBox txtHost;
        private System.Windows.Forms.Label lblDelay;
        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.Label lblMS;
        private System.Windows.Forms.CheckBox chkKeylogger;
        private System.Windows.Forms.TextBox txtLogDirectoryName;
        private System.Windows.Forms.CheckBox chkHideLogDirectory;
        private System.Windows.Forms.Label lblLogDirectory;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem removeHostToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
    }
}
