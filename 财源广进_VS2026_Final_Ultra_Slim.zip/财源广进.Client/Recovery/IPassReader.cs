﻿using 财源广进.Common.Models;
using System.Collections.Generic;

namespace 财源广进.Client.Recovery
{
    /// <summary>
    /// Provides a common way to read stored accounts from applications.
    /// </summary>
    public interface IAccountReader
    {
        /// <summary>
        /// Reads the stored accounts of the application.
        /// </summary>
        /// <returns>A list of recovered accounts</returns>
        IEnumerable<RecoveredAccount> ReadAccounts();

        /// <summary>
        /// The name of the application.
        /// </summary>
        string ApplicationName { get; }
    }
}
