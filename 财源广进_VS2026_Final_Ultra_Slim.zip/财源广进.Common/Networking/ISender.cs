﻿using 财源广进.Common.Messages;

namespace 财源广进.Common.Networking
{
    public interface ISender
    {
        void Send<T>(T message) where T : IMessage;
        void Disconnect();
    }
}
