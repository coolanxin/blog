using System;
using System.Security.Cryptography;
using System.Text;

namespace 财源广进.Common.Cryptography
{
    public static class MemoryProtection
    {
        // 内存加密必须是 16 字节的倍数
        private const int BlockSize = 16;

        public static byte[] Protect(string data)
        {
            if (string.IsNullOrEmpty(data)) return null;
            byte[] raw = Encoding.UTF8.GetBytes(data);
            int paddedLength = ((raw.Length + BlockSize - 1) / BlockSize) * BlockSize;
            byte[] padded = new byte[paddedLength];
            Buffer.BlockCopy(raw, 0, padded, 0, raw.Length);

            try
            {
                ProtectedMemory.Protect(padded, MemoryProtectionScope.SameProcess);
                return padded;
            }
            catch
            {
                return raw; // 如果系统不支持，则回退到明文
            }
        }

        public static string Unprotect(byte[] data)
        {
            if (data == null) return string.Empty;
            byte[] clone = (byte[])data.Clone();
            try
            {
                ProtectedMemory.Unprotect(clone, MemoryProtectionScope.SameProcess);
                string result = Encoding.UTF8.GetString(clone).TrimEnd('\0');
                // 使用后立即擦除克隆的明文数据
                Array.Clear(clone, 0, clone.Length);
                return result;
            }
            catch
            {
                return Encoding.UTF8.GetString(data).TrimEnd('\0');
            }
        }
    }
}
