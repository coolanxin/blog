﻿namespace 财源广进.Common.Enums
{
    public enum ShutdownAction
    {
        Shutdown,
        Restart,
        Standby
    }
}
