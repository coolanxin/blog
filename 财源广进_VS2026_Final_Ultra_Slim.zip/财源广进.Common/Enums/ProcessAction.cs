﻿namespace 财源广进.Common.Enums
{
    public enum ProcessAction
    {
        Start,
        End
    }
}
