﻿namespace 财源广进.Common.Enums
{
    public enum StartupType
    {
        LocalMachineRun,
        LocalMachineRunOnce,
        CurrentUserRun,
        CurrentUserRunOnce,
        StartMenu,
        LocalMachineRunX86,
        LocalMachineRunOnceX86
    }
}
