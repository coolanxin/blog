﻿namespace 财源广进.Common.Enums
{
    public enum FileType
    {
        File,
        Directory,
        Back
    }
}
