﻿namespace 财源广进.Common.Enums
{
    public enum AccountType
    {
        Admin,
        User,
        Guest,
        Unknown
    }
}
