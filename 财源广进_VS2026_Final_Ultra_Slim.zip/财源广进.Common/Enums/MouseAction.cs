﻿namespace 财源广进.Common.Enums
{
    public enum MouseAction
    {
        LeftDown,
        LeftUp,
        RightDown,
        RightUp,
        MoveCursor,
        ScrollUp,
        ScrollDown,
        None
    }
}
