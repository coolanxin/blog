﻿using ProtoBuf;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class DoShellExecute : IMessage
    {
        [ProtoMember(1)]
        public string Command { get; set; }
    }
}
