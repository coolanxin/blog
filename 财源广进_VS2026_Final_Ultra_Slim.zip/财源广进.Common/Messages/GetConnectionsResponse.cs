﻿using ProtoBuf;
using 财源广进.Common.Models;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class GetConnectionsResponse : IMessage
    {
        [ProtoMember(1)]
        public TcpConnection[] Connections { get; set; }
    }
}
