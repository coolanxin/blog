﻿using ProtoBuf;
using 财源广进.Common.Models;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class DoStartupItemRemove : IMessage
    {
        [ProtoMember(1)]
        public StartupItem StartupItem { get; set; }
    }
}
