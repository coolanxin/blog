﻿using ProtoBuf;
using 财源广进.Common.Enums;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class SetUserStatus : IMessage
    {
        [ProtoMember(1)]
        public UserStatus Message { get; set; }
    }
}
