﻿using ProtoBuf;
using 财源广进.Common.Models;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class GetDrivesResponse : IMessage
    {
        [ProtoMember(1)]
        public Drive[] Drives { get; set; }
    }
}
