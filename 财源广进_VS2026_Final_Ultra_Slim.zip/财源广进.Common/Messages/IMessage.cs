﻿namespace 财源广进.Common.Messages
{
    public interface IMessage
    {
    }
}
