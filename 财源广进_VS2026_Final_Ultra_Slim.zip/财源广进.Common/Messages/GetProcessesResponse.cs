﻿using ProtoBuf;
using 财源广进.Common.Models;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class GetProcessesResponse : IMessage
    {
        [ProtoMember(1)]
        public Process[] Processes { get; set; }
    }
}
