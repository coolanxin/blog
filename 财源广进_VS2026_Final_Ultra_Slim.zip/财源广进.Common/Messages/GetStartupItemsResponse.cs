﻿using ProtoBuf;
using 财源广进.Common.Models;
using System.Collections.Generic;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class GetStartupItemsResponse : IMessage
    {
        [ProtoMember(1)]
        public List<StartupItem> StartupItems { get; set; }
    }
}
