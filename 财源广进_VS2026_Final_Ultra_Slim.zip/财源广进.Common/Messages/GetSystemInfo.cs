﻿using ProtoBuf;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class GetSystemInfo : IMessage
    {
    }
}
