﻿using ProtoBuf;
using 财源广进.Common.Enums;

namespace 财源广进.Common.Messages
{
    [ProtoContract]
    public class DoPathDelete : IMessage
    {
        [ProtoMember(1)]
        public string Path { get; set; }

        [ProtoMember(2)]
        public FileType PathType { get; set; }
    }
}
