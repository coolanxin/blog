using ProtoBuf;
using System.IO;

namespace 财源广进.Common.Messages
{
    public static class MsgSerializer
    {
        public static void Serialize<T>(Stream stream, T instance)
        {
            ProtoBuf.Serializer.Serialize(stream, instance);
        }

        public static IMessage Deserialize(Stream stream)
        {
            return ProtoBuf.Serializer.Deserialize<IMessage>(stream);
        }
    }
}
